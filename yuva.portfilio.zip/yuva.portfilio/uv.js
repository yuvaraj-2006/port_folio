document.addEventListener('DOMContentLoaded',function(){
    var btn=document.getElementById('btn');
    btn.addEventListener('click',()=>{
        alert('Resume Downloaded and Opened');
    });
});